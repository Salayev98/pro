﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task20.Enums
{
    enum Type
    {
        Bakery,
        Drink,
        Meat,
        Fish
    }
}
