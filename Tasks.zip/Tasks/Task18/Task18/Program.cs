﻿using System;

namespace Task18
{
    class Program
    {
        static void Main(string[] args)
        {
           
        }
    }
}
