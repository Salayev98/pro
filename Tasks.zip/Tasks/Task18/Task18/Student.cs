﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task18
{
    class Student
    {
        public static int Count = 100;
        public string Fullname;
        private string _groupno;
        public string Groupno
        {
            get => _groupno;

            set
            {


                
            }
        }
        public int Age;
    }
}
