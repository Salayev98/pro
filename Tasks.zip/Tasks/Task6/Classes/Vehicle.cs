﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
    class Vehicle
    {
        public string Colour;
        public int Year;
        public Vehicle(int year) 
        {
            Year = year;
        }
    }
}
