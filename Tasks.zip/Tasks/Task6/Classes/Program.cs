﻿using System;

namespace Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
