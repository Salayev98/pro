﻿using System;

namespace Task16
{
    class Program
    {
        static void Main(string[] args)
        {
            //string name = Console.ReadLine();
            //Company company = new Company(name);

            

        }
    }
}
