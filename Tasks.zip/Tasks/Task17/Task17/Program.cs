﻿using System;

namespace Task17
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
