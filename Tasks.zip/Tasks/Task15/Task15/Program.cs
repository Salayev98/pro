﻿using System;

namespace Task15
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
