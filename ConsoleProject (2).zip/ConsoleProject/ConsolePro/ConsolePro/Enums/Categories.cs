﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsolePro.Enums
{
    enum Categories
    {
        Sudluk =1,
        Su,
        Qastranom

    }
}
